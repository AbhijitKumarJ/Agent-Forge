# Configuration settings for the Agent Workbench

# Example setting
LOG_LEVEL = "INFO"
AGENT_MEMORY_TYPE = "local_file" # or "database", "cloud_storage"
DATA_PATH = "../data/" # Relative path to the data directory
